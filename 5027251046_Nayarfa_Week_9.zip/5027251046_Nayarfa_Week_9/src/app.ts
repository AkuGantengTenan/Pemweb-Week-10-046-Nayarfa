import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { requestLogger } from "./middleware/request-logger.js";
import productRouter from "./routes/product.routes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(express.json());
app.use(requestLogger);
app.use(express.static(path.join(__dirname, "../public")));

app.use("/api/products", productRouter);

export default app;
