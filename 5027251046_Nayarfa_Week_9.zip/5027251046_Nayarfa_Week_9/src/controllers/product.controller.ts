import type { Request, Response } from "express";

export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  stock: number;
}

let products: Product[] = [
  { id: 1, name: "Buku Tulis Campus", category: "Alat Tulis", price: 6500, stock: 45 },
  { id: 2, name: "Pulpen Faster C6", category: "Alat Tulis", price: 3500, stock: 80 },
  { id: 3, name: "Kertas HVS A4 80gr", category: "Kertas", price: 52000, stock: 20 }
];

let nextId = 4;

export function getProducts(_req: Request, res: Response) {
  res.status(200).json(products);
}

export function createProduct(req: Request, res: Response) {
  const { name, category, price, stock } = req.body ?? {};

  if (!name || !category || price === undefined || stock === undefined) {
    res.status(400).json({ message: "Semua kolom wajib diisi" });
    return;
  }

  const newProduct: Product = {
    id: nextId++,
    name: String(name).trim(),
    category: String(category).trim(),
    price: Number(price),
    stock: Number(stock)
  };

  products.push(newProduct);
  res.status(201).json(newProduct);
}

export function updateProduct(req: Request, res: Response) {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);

  if (index === -1) {
    res.status(404).json({ message: "Data barang tidak ditemukan" });
    return;
  }

  const { name, category, price, stock } = req.body ?? {};

  if (!name || !category || price === undefined || stock === undefined) {
    res.status(400).json({ message: "Semua kolom wajib diisi" });
    return;
  }

  products[index] = {
    id,
    name: String(name).trim(),
    category: String(category).trim(),
    price: Number(price),
    stock: Number(stock)
  };

  res.status(200).json(products[index]);
}

export function deleteProduct(req: Request, res: Response) {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);

  if (index === -1) {
    res.status(404).json({ message: "Data barang tidak ditemukan" });
    return;
  }

  const deleted = products.splice(index, 1)[0];
  res.status(200).json({ message: "Data berhasil dihapus", data: deleted });
}
