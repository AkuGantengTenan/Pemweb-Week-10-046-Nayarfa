const form = document.getElementById("product-form");
const formTitle = document.getElementById("form-title");
const productIdInput = document.getElementById("product-id");
const nameInput = document.getElementById("name");
const categoryInput = document.getElementById("category");
const priceInput = document.getElementById("price");
const stockInput = document.getElementById("stock");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-btn");
const productList = document.getElementById("product-list");

let currentProducts = [];

function formatRupiah(value) {
  return "Rp" + Number(value).toLocaleString("id-ID");
}

async function fetchProducts() {
  const response = await fetch("/api/products");
  currentProducts = await response.json();
  renderTable();
}

function renderTable() {
  productList.innerHTML = "";

  if (currentProducts.length === 0) {
    productList.innerHTML = `<tr><td colspan="6" class="empty-row">Belum ada data barang.</td></tr>`;
    return;
  }

  currentProducts.forEach((item) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${item.id}</td>
      <td>${item.name}</td>
      <td>${item.category}</td>
      <td>${formatRupiah(item.price)}</td>
      <td>${item.stock}</td>
      <td>
        <button type="button" class="btn btn-edit" onclick="startEdit(${item.id})">Edit</button>
        <button type="button" class="btn btn-delete" onclick="removeProduct(${item.id})">Hapus</button>
      </td>
    `;
    productList.appendChild(tr);
  });
}

function startEdit(id) {
  const item = currentProducts.find((p) => p.id === id);
  if (!item) return;

  productIdInput.value = item.id;
  nameInput.value = item.name;
  categoryInput.value = item.category;
  priceInput.value = item.price;
  stockInput.value = item.stock;

  formTitle.textContent = "Edit Data Barang (ID: " + item.id + ")";
  submitBtn.textContent = "Update";
  cancelBtn.classList.remove("hidden");
  nameInput.focus();
}

function resetForm() {
  form.reset();
  productIdInput.value = "";
  formTitle.textContent = "Tambah Barang Baru";
  submitBtn.textContent = "Simpan";
  cancelBtn.classList.add("hidden");
}

async function removeProduct(id) {
  await fetch(`/api/products/${id}`, {
    method: "DELETE"
  });

  if (Number(productIdInput.value) === id) {
    resetForm();
  }

  await fetchProducts();
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    name: nameInput.value.trim(),
    category: categoryInput.value.trim(),
    price: Number(priceInput.value),
    stock: Number(stockInput.value)
  };

  const editId = productIdInput.value;

  if (editId) {
    await fetch(`/api/products/${editId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } else {
    await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  }

  resetForm();
  await fetchProducts();
});

cancelBtn.addEventListener("click", () => {
  resetForm();
});

fetchProducts();
